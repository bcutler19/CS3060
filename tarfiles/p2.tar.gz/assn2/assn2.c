/*Promise of Originality
I Brayden promise that this source code file, has in it's entirety
been written by myself and by not other person or persons. 
If an exact copy of this source is found to be used by another 
person in this term, I understand that both myself and the student
that submitted the copy will receive a zero on this assignment.
*/

#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc,char **argv)
{
pid_t pid;
	/* fork a child process */
	// pid works with an integer data type as well
	pid = fork();
	printf("PARENT started, now waiting for process ID# %d\n", (int)getpid()) ;

	if (pid < 0) { // error occurred
		fprintf(stderr, "Fork Failed");
	 	return 1;
	}
	else if( pid == 0) { // child process
		printf("I am the child with pid# %d \n", (int) getpid());
		if(argc == 0)
		{
			printf("There were no arguments provided. Terminating child.\n");
		}
		else if(argc == 1)
		{
			printf("One argument provided. Calling execlp(), never to return (sniffles) :'(\n");
			execlp("bin/ls", "ls", NULL);
		}
		else
		{
			printf("More than one argument provided. Calling execvp(), never to return (sniffles) :'(\n");
			execvp("bin/ls", argv);
		}
	}
	else{
		wait(NULL);
		printf("Parent resume. Child exit code of 0. Now terminating the parent \n");
	}
	return 0;
}

