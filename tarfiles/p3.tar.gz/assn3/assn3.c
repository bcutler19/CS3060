
/*
Brayden Cutler, CS 3060, Utah Valley University, 
I promise that this source code file has, in it's entirety, been
written by myself and by no other person or persons. If at any time an
exact copy of this source code is found to be used by another person in
this term, I understand that both myself and the student that submitted
the copy will receive a zero on this assignment.
*/

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
//int sum;
 struct newCont
{
    int input;
    int outputs[50];
};
void *runner(void *param) {
    struct newCont *out = malloc(sizeof(struct newCont));
    int num = atoi(param);
    int j = 0;
    int i =1;
    out->input = num;
    while(j != 1){
     if(num%2==0 && num != 2){
         out->outputs[i] = 2;
         num = num/2;
         i++;
     }   
     else if(num%3==0 && num != 3){
         out->outputs[i] = 3;
         num = num/3;
         i++;
     }
     else{
         out->outputs[i] = num;
         j=1;
     }
        
    }
        pthread_exit(out);
}
int main(int argc, char *argv[]) {
   // pthread_t tid;
    pthread_t workers[argc]; //thread identifier
    pthread_attr_t attr; // set of thread attributes
    struct newCont *container1;
    printf("Assignment 3: By Brayden Cutler \n");
    //int outNums [sizeof(argv)];

    if (argc < 2)
    {
       fprintf(stderr, " <Number to Factor>\n");
      return -1;
    }
    if (atoi(argv[1]) < 0)
    {
        fprintf(stderr, "%d must be >= 0\n", atoi(argv[1]));
        return -1;
    }
    for(int i = 1; i <= argc-1; i++){
        //get the default attributes
        pthread_attr_init(&attr);
        //create the thread
        pthread_create(&workers[i],&attr,runner,argv[i]);
        
         // pthread_join(tid,(void **)&myTest);

        //printf("sum = %d\n", myTest->input);
   }
    for(int i=1; i <= argc-1; i++){
        //wait for the thread to exit
       pthread_join(workers[i],(void **)&container1);
       //outNums[i]=myTest->input;

       printf("%d: ", container1->input);
       for(int j = 1; container1->outputs[j]!=0; j++)
            printf("%d ", container1->outputs[j]);
        printf("\n");
        
        free (container1);
    }



}


